clear
echo
echo
echo -e "\e[96m\e[1m Installing Required Packages for BASH LOCK"
echo
echo
termux-setup-storage
apt update -y
pkg install nodejs -y
npm install -g bash-obfuscate
termux-setup-storage
clear
echo
echo -e "\e[96m ------------\e[93m( \e[92mBash Lock Created BY htr-tech \e[93m)\e[96m------------"
echo
echo -e "\e[96m ------------\e[92m( \e[93mgithub.com/htr-tech \e[92m)\e[96m------------"
echo
echo -e "\e[92m\e[1m Installation Succeed ..."
echo
echo
echo -e "\e[96m\e[1m Type \e[93mbash bashlock \e[96m\e[1mto run \e[93mBASH LOCK"
echo -e "\e[96m"
echo