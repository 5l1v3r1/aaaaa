#!/bin/bash

banner() {
clear
printf "\e[0m\n"
printf "\e[0m\e[1;33m   ____            _      \e[0m\e[1;32m ______                   _        \e[0m\n"
printf "\e[0m\e[1;33m  |  _ \          | |     \e[0m\e[1;32m|  ____|                 | |       \e[0m\n"
printf "\e[0m\e[1;33m  | |_) | __ _ ___| |__   \e[0m\e[1;32m| |__ _   _ ___  ___ __ _| |_ ___  \e[0m\n"
printf "\e[0m\e[1;33m  |  _ < / _  / __|  _ \  \e[0m\e[1;32m|  __| | | / __|/ __/ _  | __/ _ \ \e[0m\n"
printf "\e[0m\e[1;33m  | |_) | (_| \__ \ | | | \e[0m\e[1;32m| |  | |_| \__ \ (_| (_| | ||  __/ \e[0m\n"
printf "\e[0m\e[1;33m  |____/ \__,_|___/_| |_| \e[0m\e[1;32m|_|   \__,_|___/\___\__,_|\__\___| \e[0m\n"
printf "\e[0m\n"
printf "\e[0m\e[1;33m       Created By HTR-TECH \e[0m\e[1;31m( \e[0m\e[1;33mTahmid Rayat \e[0m\e[1;31m)\e[0m\n"

}

banner
printf "\e[0m\n"
printf "\e[0m\n"
printf " \e[0m\e[1;31m[\e[0m\e[1;37m+\e[0m\e[1;31m]\e[0m\e[1;33m Initializing...\n"
printf "\e[0m\n"
apt update
sleep 2
banner
printf "\e[0m\n"
printf "\e[0m\n"
printf " \e[0m\e[1;91m[\e[0m\e[1;97m~\e[0m\e[1;91m]\e[0m\e[1;93m Creating Environment...\e[0m\n"
printf "\e[0m\n"
cp -f bashfuscate /data/data/com.termux/files/usr/bin/bashfuscate
cp -f bashfuscate /data/data/com.termux/files/usr/bin/BashFuscate
echo 'termux-open-url https://github.com/htr-tech/' > /data/data/com.termux/files/usr/bin/htr-tech
echo 'termux-open-url https://github.com/htr-tech/' > /data/data/com.termux/files/usr/bin/HTR-TECH
echo 'termux-open-url https://www.instagram.com/tahmid.rayat/' > /data/data/com.termux/files/usr/bin/instagram
echo 'termux-open-url https://www.instagram.com/tahmid.rayat/' > /data/data/com.termux/files/usr/bin/Instagram
chmod +x /data/data/com.termux/files/usr/bin/htr-tech
chmod +x /data/data/com.termux/files/usr/bin/HTR-TECH
chmod +x /data/data/com.termux/files/usr/bin/instagram
chmod +x /data/data/com.termux/files/usr/bin/Instagram
chmod +x /data/data/com.termux/files/usr/bin/bashfuscate
chmod +x /data/data/com.termux/files/usr/bin/BashFuscate
printf "\e[0m\n"
printf "\e[0m\n"
sleep 2
printf "\e[0m\n"
printf " \e[0m\e[1;91m[\e[0m\e[1;97m~\e[0m\e[1;91m]\e[0m\e[1;93m Installation Succeed !!\e[0m\n"
sleep 2
printf "\e[0m\n"
printf "\e[0m\n"
printf " \e[0m\e[1;91m[\e[0m\e[1;97m~\e[0m\e[1;91m]\e[0m\e[1;93m Type \e[0m\e[1;92mBashFuscate \e[0m\e[1;93mto Run this Tool \e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
