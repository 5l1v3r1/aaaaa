#!/bin/bash

banner() {
clear
printf "\n"
printf "\e[0m\e[1;93m   _____         ______                   _       \n"
printf "\e[0m\e[1;93m  |  __ \       |  ____|                 | |      \n"
printf "\e[0m\e[1;93m  | |__) |   _  | |__ _   _ ___  ___ __ _| |_ ___ \n"
printf "\e[0m\e[1;93m  |  ___/ | | | |  __| | | / __|/ __/ _  | __/ _ |\n"
printf "\e[0m\e[1;93m  | |   | |_| | | |  | |_| \__ \ (_| (_| | ||  __/\n"
printf "\e[0m\e[1;93m  |_|    \__, | |_|   \__,_|___/\___\__,_|\__\___|\n"
printf "\e[0m\e[1;93m          __/ |                                   \n"
printf "\e[0m\e[1;93m         |___/                                    \n"
printf "\n"
printf "  \e[0m\e[1;93mCreated By HTR-TECH \e[0m\e[1;96m( \e[0m\e[1;93mTahmid Rayat \e[0m\e[1;96m)"""

}
banner
printf "\n"
printf "\n"
sleep 2
printf " \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Installing Packages ...\e[0m\n"
echo
apt update
apt install python -y
pip install emojify
printf "\n"
printf "\n"
printf " \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Binding Packets ...\e[0m\n"
sleep 2
echo
echo
printf " \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Done !!\e[0m\n"
sleep 1
banner
printf "\n"
printf "\n"
printf "\n"
printf " \e[1;31m[\e[0m\e[1;77m~\e[0m\e[1;31m]\e[0m\e[1;92m Type\e[0m\e[1;93m bash pyfuscate\e[0m\e[1;92m to run this tool\e[0m\n"
printf "\e[0m\n"
printf "\e[0m\n"
sleep 1
exit
